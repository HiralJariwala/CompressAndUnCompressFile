﻿using System;
using System.Threading.Tasks;
using System.IO;
using System.IO.Compression;


namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            string startPath = @"C:\Users\Hiral\Documents\h";
            string zipPath = @"C:\Users\Hiral\Documents\xip.zip";
            string extractPath = @"C:\Users\Hiral\Documents\hextract";

            ZipFile.CreateFromDirectory(startPath, zipPath);

            ZipFile.ExtractToDirectory(zipPath, extractPath);
        }
    }
}

//namespace ZipandunZipFile
//{
//    class Program
//    {
//        static string filename = @"C:\Users\Hiral\Documents\hiraltextFile.txt";
//        static string outputfilename = @"C:\Users\Hiral\Desktop\txt.gzip";

//        static void compress()
//        {
//            using (FileStream inputstrem = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite))
//            {
//                using (FileStream outpustram = new FileStream(outputfilename, FileMode.OpenOrCreate, FileAccess.ReadWrite))
//                {
//                    using (GZipStream gzip = new GZipStream(outpustram, CompressionMode.Compress))
//                    {
//                        inputstrem.CopyTo(gzip);
//                    }
//                }
//            }               
//        }
//        static void UnCompress()
//        {
//            using (FileStream inputstrem = new FileStream(outputfilename, FileMode.OpenOrCreate, FileAccess.ReadWrite))
//            {
//                using (FileStream outpustram = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite))
//                {
//                    using (GZipStream gzip = new GZipStream(inputstrem, CompressionMode.Compress))
//                    {
//                        gzip.CopyTo(outpustram);
//                    }
//                }
//            }
//        }
//        static void Main(string[] args)
//        {
//            compress();
//        }
//    }
//}
